﻿namespace decoratorpattern
{
    public class EmployeeFacade
    {
        private readonly EmployeeValidateService employeeValidateService = new();
        private readonly EmployeeCreditScore employeeCreditScore = new();
        private readonly EmployeeWorthinessScore employeeWorthinessScore = new();

        public double CalculateEmployeeScore(int customerId)
        {
            if (!employeeValidateService.isEmployeeEligible(customerId))
            {
                return 0;
            }
            return employeeCreditScore.CalculateCustomerWorthiness(customerId)
                - employeeWorthinessScore.CalculateCustomerWorthiness(customerId);
        }
    }

}
