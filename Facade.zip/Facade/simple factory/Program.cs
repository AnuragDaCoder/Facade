﻿// See https://aka.ms/new-console-template for more information



using decoratorpattern;

var facade = new EmployeeFacade();
Console.WriteLine(facade.CalculateEmployeeScore(12345));