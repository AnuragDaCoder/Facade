﻿namespace decoratorpattern
{
    
    public class EmployeeValidateService
    {
        public bool isEmployeeEligible(int employeeCredit)
        {
            return employeeCredit > 100;
        }
    }

    public class EmployeeWorthinessScore
    {
        public double CalculateCustomerWorthiness(int employeeId)
        {
            //some calculation
            return 1000;
        }
    }

    public class EmployeeCreditScore
    {
        public double CalculateCustomerWorthiness(int employeeId)
        {
            //some calculation
            return 2000;
        }
    }

}
